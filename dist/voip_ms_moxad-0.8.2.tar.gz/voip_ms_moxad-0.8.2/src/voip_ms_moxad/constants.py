# constants used by format_date() function

FROM_DATE_FLAG    = 0
TO_DATE_FLAG      = 1

